import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { CSS2DRenderer } from 'three/addons/renderers/CSS2DRenderer.js';

const mainContentDiv = document.querySelector('.main-content');

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera( 75, mainContentDiv.offsetWidth / mainContentDiv.offsetHeight, 0.1, 1000 );
const loader = new GLTFLoader();
const objLoader = new OBJLoader();
const renderer = new THREE.WebGLRenderer();
renderer.setSize( mainContentDiv.offsetWidth, mainContentDiv.offsetHeight);
renderer.setClearColor( 0x323232, 1 );
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap; // default THREE.PCFShadowMap
mainContentDiv.appendChild(renderer.domElement);

window.addEventListener('resize', () => {
    camera.aspect = mainContentDiv.clientWidth / mainContentDiv.clientHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(mainContentDiv.clientWidth, mainContentDiv.clientHeight);
});
const css2DRenderer = new CSS2DRenderer(mainContentDiv);

scene.add( new THREE.AmbientLight( 0x323232 ) );

const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
directionalLight.castShadow = true;
directionalLight.position.set( 0, 1, 0 ); //default; light shining from top
directionalLight.shadow.mapSize.width = 512; // default
directionalLight.shadow.mapSize.height = 512; // default
directionalLight.shadow.camera.near = 0.5; // default
directionalLight.shadow.camera.far = 500; // default
directionalLight.target.position.set(0.5, 0, 0.5);
scene.add( directionalLight );
scene.add( directionalLight.target );

const controls = new PointerLockControls(camera, mainContentDiv);
scene.add(controls.getObject());
mainContentDiv.addEventListener('contextmenu', () => {
    controls.lock();
});
const keys = {
    forward: false,
    backward: false,
    left: false,
    right: false,
    up: false,
    down: false,
};

document.addEventListener('keydown', (event) => {
    switch (event.code) {
        case 'KeyW': keys.forward = true; break;
        case 'KeyS': keys.backward = true; break;
        case 'KeyA': keys.left = true; break;
        case 'KeyD': keys.right = true; break;
        case 'KeyR': keys.up = true; break;
        case 'KeyF': keys.down = true; break;
    }
});

document.addEventListener('keyup', (event) => {
    switch (event.code) {
        case 'KeyW': keys.forward = false; break;
        case 'KeyS': keys.backward = false; break;
        case 'KeyA': keys.left = false; break;
        case 'KeyD': keys.right = false; break;
        case 'KeyR': keys.up = false; break;
        case 'KeyF': keys.down = false; break;
    }
});



loader.load( 'low_poly_house_interior.glb', function ( gltf ) {

    // Traverse the GLTF model to apply a custom material to each mesh
    // gltf.scene.traverse((child) => {
    //     if (child.isMesh) {
    //         // Create a custom material, e.g., a basic red color material
    //         child.material = new THREE.MeshStandardMaterial({
    //             color: getRandomColor(), // Red color
    //             roughness: 0.5,
    //             metalness: 0.1,
    //         });
    //         child.castShadow = true; // Each mesh should cast shadows
    //         child.receiveShadow = true; // Each mesh should receive shadows
    //     }
    // });

	scene.add( gltf.scene );

}, function ( xhr ) {

    console.log( ( xhr.loaded / xhr.total * 100 ) + '% loaded' );

}, function ( error ) {

	console.error( error );

} );



const moveSpeed = 0.1;

function animate() {
    requestAnimationFrame(animate);
    updateControls();
	renderer.render( scene, camera );
}
animate();



function updateControls() {
    const direction = new THREE.Vector3();
    if (keys.forward) direction.z += moveSpeed;
    if (keys.backward) direction.z -= moveSpeed;
    if (keys.left) direction.x -= moveSpeed;
    if (keys.right) direction.x += moveSpeed;
    if (keys.up) camera.position.y += moveSpeed;
    if (keys.down) camera.position.y -= moveSpeed;
    
    controls.moveRight(direction.x);
    controls.moveForward(direction.z);
}

