const sidebar = document.querySelector('.sidebar');
const mainContent = document.querySelector('.main-content');
const divider = document.querySelector('.divider');
let isResizing = false;

// Mouse Down Event on Divider
divider.addEventListener('mousedown', function (e) {
    isResizing = true;
    document.body.style.cursor = 'ew-resize'; // Change cursor on resize
});

// Mouse Up Event - Stop resizing
window.addEventListener('mouseup', function () {
    isResizing = false;
    document.body.style.cursor = 'default'; // Reset cursor
});

// Mouse Move Event - Handle the resizing logic
window.addEventListener('mousemove', function (e) {
    if (!isResizing) return;

    // Calculate the new sidebar width
    const containerRect = document.querySelector('.container').getBoundingClientRect();
    const newWidth = e.clientX - containerRect.left;

    // Apply the new width to the sidebar and adjust main content
    if (newWidth > 100 && newWidth < containerRect.width - 100) { // Keep within min/max limits
        sidebar.style.width = `${newWidth}px`;
    }
});